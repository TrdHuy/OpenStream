/* @ds-bundle: {"format":4,"namespace":"SamsungDisplayELearningDesignSystem_033963","components":[{"name":"ChecklistItem","sourcePath":"components/content/ChecklistItem.jsx"},{"name":"Eyebrow","sourcePath":"components/content/Eyebrow.jsx"},{"name":"InfoCard","sourcePath":"components/content/InfoCard.jsx"},{"name":"ListItem","sourcePath":"components/content/ListItem.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal.jsx"},{"name":"OutputPanel","sourcePath":"components/feedback/OutputPanel.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"TextareaField","sourcePath":"components/forms/TextareaField.jsx"},{"name":"Header","sourcePath":"components/layout/Header.jsx"},{"name":"HeroBlock","sourcePath":"components/layout/HeroBlock.jsx"},{"name":"LandscapeCard","sourcePath":"components/layout/LandscapeCard.jsx"}],"sourceHashes":{"components/content/ChecklistItem.jsx":"6ac84ee2f3f1","components/content/Eyebrow.jsx":"57eb2a44113a","components/content/InfoCard.jsx":"a83bc6d49756","components/content/ListItem.jsx":"cfb8353121a9","components/feedback/Modal.jsx":"4f04dbfe5e6d","components/feedback/OutputPanel.jsx":"795a7a80dcad","components/forms/Button.jsx":"8102a06d15c1","components/forms/TextareaField.jsx":"5fa8e3fc2ebb","components/layout/Header.jsx":"2a6783c9096d","components/layout/HeroBlock.jsx":"8fc68a3ede90","components/layout/LandscapeCard.jsx":"d0301760ba78"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SamsungDisplayELearningDesignSystem_033963 = window.SamsungDisplayELearningDesignSystem_033963 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/ChecklistItem.jsx
try { (() => {
function ChecklistItem({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("li", {
    style: {
      listStyle: "none",
      marginBottom: 16,
      display: "flex",
      gap: 8,
      font: "var(--text-body-md)",
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: "var(--interactive-blue)"
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--text-strong)"
    }
  }, label, ":"), " ", children));
}
Object.assign(__ds_scope, { ChecklistItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ChecklistItem.jsx", error: String((e && e.message) || e) }); }

// components/content/Eyebrow.jsx
try { (() => {
function Eyebrow({
  light,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-block",
      font: "var(--text-eyebrow)",
      textTransform: "uppercase",
      letterSpacing: "var(--eyebrow-tracking)",
      marginBottom: 8,
      padding: "4px 12px",
      borderRadius: "var(--radius-pill)",
      color: light ? "#fff" : "var(--interactive-blue)",
      background: light ? "rgba(255,255,255,0.15)" : "var(--interactive-blue-soft)"
    }
  }, children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/content/InfoCard.jsx
try { (() => {
function InfoCard({
  title,
  description,
  meta,
  onClick
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      padding: 16,
      background: "var(--surface-muted)",
      borderRadius: "var(--radius-lg)",
      marginBottom: 16,
      border: "1px solid var(--border-subtle)",
      borderLeft: "4px solid var(--interactive-blue)",
      cursor: onClick ? "pointer" : "default",
      transition: "transform .2s,box-shadow .2s"
    },
    onMouseEnter: e => {
      if (onClick) {
        e.currentTarget.style.transform = "translateY(-2px)";
        e.currentTarget.style.boxShadow = "0 6px 16px rgba(0,0,0,0.08)";
      }
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "none";
      e.currentTarget.style.boxShadow = "none";
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--text-card-heading)",
      fontSize: 20,
      color: "var(--text-strong)",
      margin: "0 0 8px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-body-md)",
      color: "var(--text-body)",
      margin: 0
    }
  }, description), meta && /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-body-sm)",
      margin: "8px 0 0"
    }
  }, /*#__PURE__*/React.createElement("strong", null, meta)), onClick && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      marginTop: 16,
      background: "var(--rich-black)",
      color: "#fff",
      padding: "6px 16px",
      borderRadius: "var(--radius-pill)",
      fontSize: 13,
      fontWeight: 600
    }
  }, "Click to view"));
}
Object.assign(__ds_scope, { InfoCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/InfoCard.jsx", error: String((e && e.message) || e) }); }

// components/content/ListItem.jsx
try { (() => {
function ListItem({
  number,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      marginBottom: 16,
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: "var(--radius-lg)",
      background: "var(--interactive-blue-soft)",
      color: "var(--interactive-blue)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      fontWeight: 700,
      font: "var(--text-body-md)"
    }
  }, number), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--text-card-heading)",
      fontSize: 18,
      color: "var(--text-strong)",
      margin: "0 0 4px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-body-md)",
      color: "var(--text-body)",
      margin: 0
    }
  }, children)));
}
Object.assign(__ds_scope, { ListItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ListItem.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Modal.jsx
try { (() => {
function Modal({
  open,
  title,
  image,
  onClose,
  children
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,0.6)",
      backdropFilter: "blur(4px)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: "relative",
      width: "100%",
      maxWidth: 450
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      position: "absolute",
      top: -12,
      right: -8,
      background: "var(--rich-black)",
      color: "#fff",
      border: "none",
      width: 32,
      height: 32,
      borderRadius: "50%",
      cursor: "pointer",
      fontWeight: 700,
      zIndex: 10000
    }
  }, "\u2715"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)",
      padding: 24,
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-modal)",
      maxHeight: "85vh",
      overflowY: "auto"
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: "100%",
      height: 250,
      objectFit: "contain",
      borderRadius: "var(--radius-md)",
      marginBottom: 16
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--text-card-heading)",
      fontSize: 20,
      color: "var(--text-strong)",
      margin: "0 0 8px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: "var(--text-body-md)",
      fontSize: 15,
      margin: 0
    }
  }, children))));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Modal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/OutputPanel.jsx
try { (() => {
function OutputPanel({
  heading,
  children,
  visible
}) {
  if (!visible) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      padding: 24,
      background: "var(--surface-muted)",
      borderRadius: "var(--radius-xl)",
      border: "1px solid var(--border-subtle)"
    }
  }, heading && /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "var(--text-card-heading)",
      fontSize: 20,
      margin: "0 0 8px",
      color: "var(--text-strong)"
    }
  }, heading), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      background: "var(--surface-page)",
      padding: 16,
      borderRadius: "var(--radius-md)",
      border: "1px solid var(--border-subtle)",
      whiteSpace: "pre-wrap",
      color: "var(--text-heading)"
    }
  }, children));
}
Object.assign(__ds_scope, { OutputPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/OutputPanel.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function Button({
  children,
  loading,
  disabled,
  full = true,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    disabled: disabled || loading,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      background: disabled ? "var(--border-default)" : "var(--interactive-blue)",
      color: "#fff",
      font: "var(--text-body-md)",
      fontWeight: 500,
      padding: "16px 24px",
      borderRadius: "var(--radius-pill)",
      border: "none",
      cursor: disabled || loading ? "not-allowed" : "pointer",
      width: full ? "100%" : "auto",
      opacity: 1,
      transition: "opacity .2s"
    },
    onMouseEnter: e => {
      if (!disabled && !loading) e.currentTarget.style.opacity = 0.85;
    },
    onMouseLeave: e => {
      e.currentTarget.style.opacity = 1;
    }
  }, loading ? "Generating…" : children, loading && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      border: "2px solid rgba(255,255,255,0.3)",
      borderTopColor: "#fff",
      borderRadius: "50%",
      display: "inline-block",
      animation: "spin 1s linear infinite"
    }
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextareaField.jsx
try { (() => {
function TextareaField({
  placeholder,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("textarea", {
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    style: {
      width: "100%",
      padding: 16,
      border: "1px solid var(--border-input)",
      borderRadius: "var(--radius-lg)",
      font: "var(--text-body-md)",
      resize: "vertical",
      minHeight: 120,
      outline: "none"
    },
    onFocus: e => e.currentTarget.style.borderColor = "var(--interactive-blue)",
    onBlur: e => e.currentTarget.style.borderColor = "var(--border-input)"
  });
}
Object.assign(__ds_scope, { TextareaField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextareaField.jsx", error: String((e && e.message) || e) }); }

// components/layout/Header.jsx
try { (() => {
function Header({
  title,
  tag,
  context
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: "var(--surface-nav)",
      color: "#fff",
      padding: "20px 32px",
      width: "100%",
      borderBottom: "1px solid rgba(0,0,0,0.2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1120,
      margin: "0 auto",
      display: "flex",
      flexWrap: "wrap",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "var(--text-card-heading)",
      fontSize: 24,
      letterSpacing: "-0.01em",
      display: "flex",
      alignItems: "center",
      gap: 16,
      margin: 0
    }
  }, title, tag && /*#__PURE__*/React.createElement("span", {
    style: {
      font: "var(--text-body-sm)",
      fontWeight: 600,
      background: "var(--interactive-blue-soft-2)",
      color: "var(--interactive-blue)",
      padding: "6px 16px",
      borderRadius: "var(--radius-pill)",
      border: "1px solid rgba(0,98,255,0.3)",
      textTransform: "uppercase",
      letterSpacing: "var(--nav-tracking)"
    }
  }, tag)), context && /*#__PURE__*/React.createElement("div", {
    style: {
      font: "var(--text-body-sm)",
      color: "#94a3b8"
    }
  }, context)));
}
Object.assign(__ds_scope, { Header });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Header.jsx", error: String((e && e.message) || e) }); }

// components/layout/HeroBlock.jsx
try { (() => {
function HeroBlock({
  eyebrow,
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-inverse)",
      color: "#fff",
      textAlign: "center",
      padding: "48px 32px",
      borderRadius: "var(--radius-2xl)"
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-block",
      font: "var(--text-body-sm)",
      fontWeight: 700,
      color: "#fff",
      textTransform: "uppercase",
      letterSpacing: "var(--eyebrow-tracking)",
      marginBottom: 8,
      background: "rgba(255,255,255,0.15)",
      padding: "4px 12px",
      borderRadius: "var(--radius-pill)"
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "var(--text-display-lg)",
      color: "#fff",
      margin: 0
    }
  }, title), children && /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-on-dark-muted)",
      fontSize: 20,
      maxWidth: 700,
      margin: "16px auto 0",
      font: "var(--text-body-md)",
      fontSize: 20
    }
  }, children));
}
Object.assign(__ds_scope, { HeroBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/HeroBlock.jsx", error: String((e && e.message) || e) }); }

// components/layout/LandscapeCard.jsx
try { (() => {
function LandscapeCard({
  image,
  reverse,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)",
      borderRadius: "var(--radius-2xl)",
      boxShadow: "var(--shadow-card)",
      border: "1px solid var(--border-subtle)",
      overflow: "hidden",
      display: "flex",
      flexDirection: reverse ? "row-reverse" : "row",
      alignItems: "stretch"
    }
  }, image && /*#__PURE__*/React.createElement("div", {
    style: {
      width: "40%",
      flexShrink: 0,
      position: "relative",
      borderRight: reverse ? "none" : "1px solid var(--border-subtle)",
      borderLeft: reverse ? "1px solid var(--border-subtle)" : "none"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      flex: 1,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center"
    }
  }, children));
}
Object.assign(__ds_scope, { LandscapeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/LandscapeCard.jsx", error: String((e && e.message) || e) }); }

__ds_ns.ChecklistItem = __ds_scope.ChecklistItem;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.InfoCard = __ds_scope.InfoCard;

__ds_ns.ListItem = __ds_scope.ListItem;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.OutputPanel = __ds_scope.OutputPanel;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.TextareaField = __ds_scope.TextareaField;

__ds_ns.Header = __ds_scope.Header;

__ds_ns.HeroBlock = __ds_scope.HeroBlock;

__ds_ns.LandscapeCard = __ds_scope.LandscapeCard;

})();
